// export const loginTest = (password:string,phone:string) => {
//     const mockUser:{phone:string,password:string} = {
//         phone: "09011309598",
//         password: "abcddcba"
//     };

//     if(phone!==mockUser.phone ){
//         return { success: false, message: "User not found" };
//     }
//     if(password !== mockUser.password){
//         return { success: false, message: "Incorrect password" };
//     }
//     if(password === mockUser.password && phone === mockUser.phone){
//         return { success: true, message: "Login successful" ,token:"mock-jwt-token"};
//     }
 
// }